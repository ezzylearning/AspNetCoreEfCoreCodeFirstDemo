﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AspNetCoreEfCoreCodeFirstDemo.Migrations
{
    public partial class AddMobileInCustomers : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Mobile",
                table: "Customers",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Mobile",
                table: "Customers");
        }
    }
}
